import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-fundraise',
  templateUrl: './fundraise.component.html' 
})
export class FundraiseComponent implements OnInit {
public data=[];
constructor() { }

  ngOnInit() {
    
  }

}
