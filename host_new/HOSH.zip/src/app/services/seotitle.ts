export interface ISeotitle{
    id:number,
    title:string,
    description:string,
    keywords:string;
}