import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-impacted-lives-start',
  templateUrl: './impacted-lives-start.component.html' 
})
export class ImpactedLivesStartComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  } 
}
