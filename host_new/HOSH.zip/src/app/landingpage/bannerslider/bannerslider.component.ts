import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bannerslider',
  templateUrl: './bannerslider.component.html',
  styleUrls: ['./bannerslider.component.css']
})
export class BannersliderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
