import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-landingpage-start',
  templateUrl: './landingpage-start.component.html' 
})
export class LandingpageStartComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  } 
}
