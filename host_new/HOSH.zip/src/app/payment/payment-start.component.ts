import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payment-start',
  templateUrl: './payment-start.component.html' 
})
export class PaymentStartComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
