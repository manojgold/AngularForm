export class DonorDonations {
    constructor(
       public ALL_DONATED_NEEDS: number,
       public IN_PROCESS: number,
       public COMPLETED_NEEDS: number,
       public ERROR: String
    ){}
}
