export class Campaigners {
    constructor(
        public DONORID: number,
        public DONOR_USERNAME: string,
        public DONOR_EMAILID: string,
        public DONOR_MOBILE: number,
        public DONOR_PROFILE_IMAGE: string,
        public DONOR_PROFILE_IMAGE_FILEPATH: string,
        public DONOR_APIUSERID: string,
        public ISPRIVATE: number,
        public ERROR: string,
    ){}
}
