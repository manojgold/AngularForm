export class SimilarNeedsByNeedId {
}
