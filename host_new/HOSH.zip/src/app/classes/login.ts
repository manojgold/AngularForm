export class LoginClass {
    constructor(
       DONORID: number,
       API_USERID:string,
       accessToken:string
    ){}
}
