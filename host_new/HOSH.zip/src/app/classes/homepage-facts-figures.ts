export class HomepageFactsFigures {
    constructor(
        public NEW_NEEDS : number,
        public NEEDS_MET : number,
        public NEEDS_IN_PROGRESS : number,
        public ERROR : string,
        public TOTAL_NEEDS : number,
        public NEW_NEEDS_PERC: number,
        public NEEDS_IN_PROGRESS_PERC: number,
        public NEEDS_MET_PERC: number,
    ){}
}
