export class Location {
    constructor(
        public STATEID: number,
        public ENTRYDATE: Date,
        public STATE_NAME: string,
        public REGION: string,
        public COUNTRYID: number,
        public COUNTRY_NAME: string,
        public DESCRIPTION: string,
        public STATUS: string,
        public CREATEDBY: number,
        public ERROR: string,
    ){}
}
