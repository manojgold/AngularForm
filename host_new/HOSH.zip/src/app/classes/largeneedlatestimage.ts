export class Largeneedlatestimage {
    constructor(
        public DOCUMENTID:number,
        public NEEDID:number,
        public NEED_NAME: string,
        public ENTRYDATE: string,
        public DOCUMENT_NAME: string,
        public DOCUMENT_TYPE: string,
        public DOCUMENT_TITLE: string,
        public DOCUMENT_URL: string,
        public DOCUMENT_URL_FILEPATH: string,
        public DOCUMENT_URL_2: string,
        public DOCUMENT_URL_2_FILEPATH: string,
        public DOCUMENT_URL_3: string,
        public DOCUMENT_URL_3_FILEPATH: string,
        public DOCUMENT_URL_4: string,
        public DOCUMENT_URL_4_FILEPATH: string,
        public APPROVED_BY:number,
        public APPROVED_DATE: Date,
        public APPROVED_STATUS: string,
        public IPADDRESS: string,
        public USERAGENT: string,
        public STATUS: string,
        public CREATEDBY:number,
        public ISDEFAULT:number,
        public ERROR: string
    ){}
}
