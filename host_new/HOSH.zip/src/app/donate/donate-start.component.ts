import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-donate-start',
  templateUrl: './donate-start.component.html' 
})
export class DonateStartComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  } 
}
